#!/bin/bash

mkdir /home/ubuntu/nodejs
cd /home/ubuntu/nodejs

sudo npm install